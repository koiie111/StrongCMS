<?
/*
* (c) StrongCMS
* Сайт - strongcms.ru
* Группа ВКонтакте - vk.com/strong_cms
* Автор - Александр Каплин
* Контакты - vk.com/koiie
*/
?>
	<div class="foot">
		<center>&copy; StrongCMS 2016 г.</center>
		<center>StrongCMS beta 0.1.1 </center>
	</div>
	</body>

</html>